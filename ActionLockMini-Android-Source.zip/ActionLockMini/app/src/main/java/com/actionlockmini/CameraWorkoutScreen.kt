package com.actionlockmini

import android.annotation.SuppressLint
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.pose.PoseLandmark
import java.util.concurrent.Executors
import kotlin.math.acos
import kotlin.math.sqrt

@Composable
fun CameraWorkoutScreen(
    reps: Int,
    onRep: () -> Unit,
    onClose: () -> Unit,
    hasPermission: Boolean,
    onRequestCamera: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var status by remember { mutableStateOf("Đưa toàn thân vào khung hình") }
    var ready by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF101411)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Quay lại") }
            Spacer(Modifier.weight(1f))
            Text("CAMERA SQUAT", color = Color(0xFFB7F36B))
        }
        Text("$reps", color = Color(0xFFB7F36B),
            style = MaterialTheme.typography.displayLarge)
        Text("lần hợp lệ", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))

        if (!hasPermission) {
            Button(onClick = onRequestCamera) { Text("Cấp quyền camera") }
        } else {
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val provider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val detectorOptions = PoseDetectorOptions.Builder()
                            .setDetectorMode(PoseDetectorOptions.STREAM_MODE).build()
                        val detector = PoseDetection.getClient(detectorOptions)
                        val analyzerExecutor = Executors.newSingleThreadExecutor()
                        val analyzer = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                        val counter = SquatCounter { onRep() }
                        analyzer.setAnalyzer(analyzerExecutor) { proxy ->
                            val mediaImage = proxy.image
                            if (mediaImage == null) {
                                proxy.close()
                            } else {
                                val image = InputImage.fromMediaImage(
                                    mediaImage, proxy.imageInfo.rotationDegrees
                                )
                                detector.process(image)
                                    .addOnSuccessListener { pose ->
                                        val result = counter.update(pose)
                                        ContextCompat.getMainExecutor(ctx).execute {
                                            status = result
                                        }
                                    }
                                    .addOnCompleteListener { proxy.close() }
                            }
                        }
                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA,
                                preview, analyzer
                            )
                            ready = true
                        } catch (_: Exception) {
                            status = "Không thể khởi động camera"
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )
            Spacer(Modifier.height(12.dp))
            Text(status, color = Color.White)
            Text("Giữ camera ổn định, đủ sáng và thấy rõ toàn thân.",
                color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
            Text("Kết thúc")
        }
    }
}

private class SquatCounter(private val onRep: () -> Unit) {
    private enum class Phase { UP, DOWN }
    private var phase = Phase.UP
    private var lastRepAt = 0L

    fun update(pose: Pose): String {
        val left = angle(
            pose.getPoseLandmark(PoseLandmark.LEFT_HIP),
            pose.getPoseLandmark(PoseLandmark.LEFT_KNEE),
            pose.getPoseLandmark(PoseLandmark.LEFT_ANKLE)
        )
        val right = angle(
            pose.getPoseLandmark(PoseLandmark.RIGHT_HIP),
            pose.getPoseLandmark(PoseLandmark.RIGHT_KNEE),
            pose.getPoseLandmark(PoseLandmark.RIGHT_ANKLE)
        )
        val valid = listOf(left, right).filterNotNull()
        if (valid.isEmpty()) return "Không thấy rõ chân. Hãy lùi camera ra xa."
        val kneeAngle = valid.average().toFloat()

        return when {
            kneeAngle < 105f && phase == Phase.UP -> {
                phase = Phase.DOWN
                "Đã nhận diện tư thế xuống"
            }
            kneeAngle > 155f && phase == Phase.DOWN -> {
                phase = Phase.UP
                val now = System.currentTimeMillis()
                if (now - lastRepAt > 900) {
                    lastRepAt = now
                    onRep()
                    "Hợp lệ! Tiếp tục."
                } else "Chậm lại một chút"
            }
            kneeAngle > 155f -> "Đứng thẳng, bắt đầu squat"
            else -> "Tiếp tục chuyển động"
        }
    }

    private fun angle(a: PoseLandmark?, b: PoseLandmark?, c: PoseLandmark?): Double? {
        if (a == null || b == null || c == null) return null
        if (a.inFrameLikelihood < 0.5f || b.inFrameLikelihood < 0.5f ||
            c.inFrameLikelihood < 0.5f) return null
        val abx = (a.position.x - b.position.x).toDouble()
        val aby = (a.position.y - b.position.y).toDouble()
        val cbx = (c.position.x - b.position.x).toDouble()
        val cby = (c.position.y - b.position.y).toDouble()
        val dot = abx * cbx + aby * cby
        val mag = sqrt(abx * abx + aby * aby) * sqrt(cbx * cbx + cby * cby)
        if (mag == 0.0) return null
        return Math.toDegrees(acos((dot / mag).coerceIn(-1.0, 1.0)))
    }
}
