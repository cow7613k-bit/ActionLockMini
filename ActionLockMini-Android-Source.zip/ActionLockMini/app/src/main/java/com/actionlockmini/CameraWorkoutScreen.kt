package com.actionlockmini

import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.PreviewView
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.pose.PoseLandmark
import java.util.concurrent.Executors
import kotlin.math.acos
import kotlin.math.sqrt

enum class WorkoutType(val title: String, val unit: String) {
    SQUAT("Squat", "lần"),
    PUSH_UP("Hít đất", "lần"),
    PLANK("Plank", "giây")
}

@Composable
fun CameraWorkoutScreen(
    reps: Int,
    target: Int,
    exercise: WorkoutType,
    onRep: () -> Unit,
    onPlankSecond: (Int) -> Unit,
    onClose: () -> Unit,
    hasPermission: Boolean,
    onRequestCamera: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var status by remember { mutableStateOf("Đưa toàn thân vào khung hình") }
    var plankElapsed by remember { mutableIntStateOf(0) }
    val currentProgress = if (exercise == WorkoutType.PLANK) plankElapsed else reps
    val progress = (currentProgress.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize().background(Color(0xFF101411)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Quay lại") }
            Spacer(Modifier.weight(1f))
            Text("CAMERA ${exercise.title.uppercase()}", color = Color(0xFFB7F36B))
        }
        Text(
            if (exercise == WorkoutType.PLANK) "$plankElapsed" else "$reps",
            color = Color(0xFFB7F36B),
            style = MaterialTheme.typography.displayLarge
        )
        Text("${exercise.unit} / mục tiêu $target ${exercise.unit}", color = Color.LightGray)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(10.dp),
            color = Color(0xFFB7F36B),
            trackColor = Color(0xFF344036)
        )
        Text("${(progress * 100).toInt()}% hoàn thành",
            color = Color.LightGray, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(12.dp))

        if (!hasPermission) {
            Button(onClick = onRequestCamera) { Text("Cấp quyền camera") }
        } else {
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val provider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val detectorOptions = PoseDetectorOptions.Builder()
                            .setDetectorMode(PoseDetectorOptions.STREAM_MODE).build()
                        val detector = PoseDetection.getClient(detectorOptions)
                        val analyzerExecutor = Executors.newSingleThreadExecutor()
                        val analyzer = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                        val counter = WorkoutCounter(exercise) { onRep() } { seconds ->
                            ContextCompat.getMainExecutor(ctx).execute {
                                plankElapsed = seconds
                                onPlankSecond(seconds)
                            }
                        }
                        analyzer.setAnalyzer(analyzerExecutor) { proxy ->
                            val mediaImage = proxy.image
                            if (mediaImage == null) {
                                proxy.close()
                            } else {
                                val image = InputImage.fromMediaImage(
                                    mediaImage, proxy.imageInfo.rotationDegrees
                                )
                                detector.process(image)
                                    .addOnSuccessListener { pose ->
                                        val result = counter.update(pose)
                                        ContextCompat.getMainExecutor(ctx).execute {
                                            status = result
                                        }
                                    }
                                    .addOnCompleteListener { proxy.close() }
                            }
                        }
                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA,
                                preview, analyzer
                            )
                        } catch (_: Exception) {
                            status = "Không thể khởi động camera"
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )
            Spacer(Modifier.height(12.dp))
            Text(status, color = Color.White)
            Text(
                when (exercise) {
                    WorkoutType.SQUAT -> "Đặt camera ngang hông, quay nghiêng để thấy vai, hông, gối và cổ chân. Chỉ tính khi xuống đủ sâu rồi đứng thẳng ổn định."
                    WorkoutType.PUSH_UP -> "Đặt camera chếch bên, thấy vai, khuỷu tay và hông. Chỉ tính khi hạ xuống rồi duỗi tay trở lại."
                    WorkoutType.PLANK -> "Giữ người thành đường thẳng từ vai đến hông và cổ chân. Đồng hồ chỉ chạy khi tư thế được nhận diện ổn định."
                },
                color = Color.LightGray, style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(12.dp))
        if (currentProgress >= target) {
            Text("Đã hoàn thành mục tiêu!", color = Color(0xFFB7F36B))
        }
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
            Text("Kết thúc")
        }
    }
}

private class WorkoutCounter(
    private val exercise: WorkoutType,
    private val onRep: () -> Unit,
    private val onPlankProgress: (Int) -> Unit
) {
    private enum class Phase { TOP, BOTTOM }
    private var phase = Phase.TOP
    private var bottomSince = 0L
    private var topSince = 0L
    private var lastRepAt = 0L
    private var plankStart = 0L
    private var lastPlankTick = 0L
    private var plankSecondsSent = 0

    fun update(pose: Pose): String = when (exercise) {
        WorkoutType.SQUAT -> updateSquat(pose)
        WorkoutType.PUSH_UP -> updatePushUp(pose)
        WorkoutType.PLANK -> updatePlank(pose)
    }

    private fun updateSquat(pose: Pose): String {
        val left = angle(pose, PoseLandmark.LEFT_HIP, PoseLandmark.LEFT_KNEE, PoseLandmark.LEFT_ANKLE)
        val right = angle(pose, PoseLandmark.RIGHT_HIP, PoseLandmark.RIGHT_KNEE, PoseLandmark.RIGHT_ANKLE)
        val knee = averageReliable(left, right)
            ?: return "Không thấy rõ hông, gối và cổ chân. Hãy chỉnh camera ngang hông."
        val now = SystemClock.elapsedRealtime()

        // Require a deep squat and a stable return to near-full extension.
        if (phase == Phase.TOP) {
            if (knee < 95f) {
                if (bottomSince == 0L) bottomSince = now
                if (now - bottomSince >= 250L) {
                    phase = Phase.BOTTOM
                    topSince = 0L
                    return "Đã xuống đủ sâu. Từ từ đứng thẳng."
                }
            } else {
                bottomSince = 0L
            }
            return if (knee < 125f) "Xuống thấp thêm một chút" else "Đứng thẳng, chuẩn bị squat"
        }

        if (knee > 165f) {
            if (topSince == 0L) topSince = now
            if (now - topSince >= 350L && now - lastRepAt >= 1200L) {
                lastRepAt = now
                phase = Phase.TOP
                bottomSince = 0L
                topSince = 0L
                onRep()
                return "Squat hợp lệ! Tiếp tục."
            }
        } else {
            topSince = 0L
        }
        return if (knee > 145f) "Gần thẳng rồi, duỗi chân hoàn toàn" else "Đứng lên đến tư thế thẳng"
    }

    private fun updatePushUp(pose: Pose): String {
        val left = angle(pose, PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_ELBOW, PoseLandmark.LEFT_WRIST)
        val right = angle(pose, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_WRIST)
        val elbow = averageReliable(left, right)
            ?: return "Không thấy rõ vai, khuỷu tay và cổ tay. Hãy chỉnh camera chếch bên."
        val now = SystemClock.elapsedRealtime()

        if (phase == Phase.TOP) {
            if (elbow < 90f) {
                if (bottomSince == 0L) bottomSince = now
                if (now - bottomSince >= 180L) {
                    phase = Phase.BOTTOM
                    topSince = 0L
                    return "Đã hạ đủ. Đẩy người lên và duỗi tay."
                }
            } else bottomSince = 0L
            return if (elbow < 120f) "Hạ thấp thêm một chút" else "Giữ tay duỗi, bắt đầu hít đất"
        }

        if (elbow > 155f) {
            if (topSince == 0L) topSince = now
            if (now - topSince >= 300L && now - lastRepAt >= 1000L) {
                lastRepAt = now
                phase = Phase.TOP
                bottomSince = 0L
                topSince = 0L
                onRep()
                return "Hít đất hợp lệ! Tiếp tục."
            }
        } else topSince = 0L
        return if (elbow > 135f) "Duỗi tay thêm" else "Đẩy người lên"
    }

    private fun updatePlank(pose: Pose): String {
        val shoulder = firstReliable(pose, PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER)
        val hip = firstReliable(pose, PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_HIP)
        val ankle = firstReliable(pose, PoseLandmark.LEFT_ANKLE, PoseLandmark.RIGHT_ANKLE)
        if (shoulder == null || hip == null || ankle == null) {
            lastPlankTick = 0L
            return "Không thấy rõ vai, hông và cổ chân. Hãy chỉnh camera chếch bên."
        }
        val bodyAngle = angle(shoulder, hip, ankle) ?: run {
            lastPlankTick = 0L
            return "Không nhận diện được tư thế."
        }
        val now = SystemClock.elapsedRealtime()
        if (bodyAngle >= 155f) {
            if (plankStart == 0L) {
                plankStart = now
                lastPlankTick = now
                return "Tư thế plank hợp lệ. Giữ ổn định!"
            }
            val delta = (now - lastPlankTick).coerceIn(0L, 250L)
            lastPlankTick = now
            val seconds = ((now - plankStart) / 1000L).toInt()
            if (seconds > plankSecondsSent) {
                plankSecondsSent = seconds
                onPlankProgress(seconds)
            }
            return "Đang giữ plank: ${seconds}s"
        }
        plankStart = 0L
        lastPlankTick = 0L
        return "Giữ vai, hông và cổ chân thẳng hàng"
    }

    private fun averageReliable(a: Double?, b: Double?): Float? {
        val values = listOfNotNull(a, b)
        return if (values.isEmpty()) null else values.average().toFloat()
    }

    private fun firstReliable(pose: Pose, first: Int, second: Int): PoseLandmark? {
        val a = pose.getPoseLandmark(first)
        if (a != null && a.inFrameLikelihood >= 0.65f) return a
        val b = pose.getPoseLandmark(second)
        return if (b != null && b.inFrameLikelihood >= 0.65f) b else null
    }

    private fun angle(pose: Pose, a: Int, b: Int, c: Int): Double? =
        angle(
            reliable(pose, a), reliable(pose, b), reliable(pose, c)
        )

    private fun reliable(pose: Pose, type: Int): PoseLandmark? {
        val point = pose.getPoseLandmark(type) ?: return null
        return if (point.inFrameLikelihood >= 0.65f) point else null
    }

    private fun angle(a: PoseLandmark?, b: PoseLandmark?, c: PoseLandmark?): Double? {
        if (a == null || b == null || c == null) return null
        val abx = (a.position.x - b.position.x).toDouble()
        val aby = (a.position.y - b.position.y).toDouble()
        val cbx = (c.position.x - b.position.x).toDouble()
        val cby = (c.position.y - b.position.y).toDouble()
        val dot = abx * cbx + aby * cby
        val mag = sqrt(abx * abx + aby * aby) * sqrt(cbx * cbx + cby * cby)
        if (mag == 0.0) return null
        return Math.toDegrees(acos((dot / mag).coerceIn(-1.0, 1.0)))
    }
}
