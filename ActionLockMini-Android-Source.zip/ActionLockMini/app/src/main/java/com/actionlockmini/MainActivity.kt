package com.actionlockmini

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Ink = Color(0xFF101411)
private val Panel = Color(0xFF1B241E)
private val Lime = Color(0xFFB7F36B)

class MainActivity : ComponentActivity() {
    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted.value = granted }

    companion object {
        val permissionGranted = mutableStateOf(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Lime,
                onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
            )) {
                ActionLockApp(
                    onRequestCamera = { cameraPermission.launch(Manifest.permission.CAMERA) }
                )
            }
        }
    }
}

@Composable
private fun ActionLockApp(onRequestCamera: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("actionlock", 0) }
    var username by remember { mutableStateOf(prefs.getString("username", "") ?: "") }
    var nameInput by remember { mutableStateOf(username) }
    var tab by remember { mutableIntStateOf(0) }
    var totalReps by remember { mutableIntStateOf(prefs.getInt("total_reps", 0)) }
    var totalPlankSeconds by remember { mutableIntStateOf(prefs.getInt("total_plank_seconds", 0)) }
    var target by remember { mutableIntStateOf(20) }
    var sessionReps by remember { mutableIntStateOf(0) }
    var sessionPlankSeconds by remember { mutableIntStateOf(0) }
    var selectedExercise by remember { mutableStateOf(WorkoutType.SQUAT) }
    var cameraScreen by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize(), color = Ink) {
        if (username.isBlank()) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("ACTIONLOCK", color = Lime, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(12.dp))
                Text("Tạo hồ sơ", style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold)
                Text("Chọn tên hiển thị cho bảng xếp hạng.", color = Color.LightGray)
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(
                    value = nameInput, onValueChange = { nameInput = it.take(18) },
                    label = { Text("Tên người dùng") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        val clean = nameInput.trim()
                        if (clean.isNotEmpty()) {
                            username = clean
                            prefs.edit().putString("username", clean).apply()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Bắt đầu") }
                Text("Bản thử nghiệm lưu hồ sơ trên thiết bị này.",
                    color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        } else if (cameraScreen) {
            CameraWorkoutScreen(
                reps = sessionReps,
                target = target,
                exercise = selectedExercise,
                onRep = {
                    sessionReps++
                    totalReps++
                    prefs.edit().putInt("total_reps", totalReps).apply()
                },
                onPlankSecond = { seconds ->
                    sessionPlankSeconds = seconds
                    totalPlankSeconds = maxOf(totalPlankSeconds, seconds)
                    prefs.edit().putInt("total_plank_seconds", totalPlankSeconds).apply()
                },
                onClose = { cameraScreen = false },
                hasPermission = MainActivity.permissionGranted.value,
                onRequestCamera = onRequestCamera
            )
        } else {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ACTIONLOCK MINI", color = Lime,
                            style = MaterialTheme.typography.labelLarge)
                        Text("Xin chào, $username",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                    }
                    Text("LVL ${1 + (totalReps + totalPlankSeconds / 5) / 50}",
                        color = Lime, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("TỔNG SỐ LẦN HOÀN THÀNH", color = Color.LightGray)
                        Text("$totalReps", color = Lime,
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Black)
                        LinearProgressIndicator(
                            progress = { (totalReps % 50) / 50f },
                            modifier = Modifier.fillMaxWidth(),
                            color = Lime
                        )
                        Text("${totalReps % 50}/50 đến cấp tiếp theo",
                            color = Color.LightGray)
                        Text("Plank tốt nhất: ${totalPlankSeconds}s",
                            color = Color.LightGray)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("CHỌN BÀI TẬP MỞ KHÓA", color = Lime,
                    style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WorkoutType.values().forEach { type ->
                        FilterChip(
                            selected = selectedExercise == type,
                            onClick = {
                                selectedExercise = type
                                target = if (type == WorkoutType.PLANK) 30 else 20
                            },
                            label = { Text(type.title) }
                        )
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(selectedExercise.title, fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge)
                        Text(
                            if (selectedExercise == WorkoutType.PLANK)
                                "Mục tiêu: $target giây"
                            else "Mục tiêu: $target lần",
                            color = Color.LightGray
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = {
                                target = (target - 5).coerceAtLeast(5)
                            }) { Text("-5") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = {
                                target = (target + 5).coerceAtMost(120)
                            }) { Text("+5") }
                            Spacer(Modifier.weight(1f))
                            Button(onClick = {
                                sessionReps = 0
                                sessionPlankSeconds = 0
                                if (!MainActivity.permissionGranted.value) onRequestCamera()
                                cameraScreen = true
                            }) { Text("Bắt đầu") }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 },
                        label = { Text("Tổng quan") })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 },
                        label = { Text("Xếp hạng") })
                    FilterChip(selected = tab == 2, onClick = { tab = 2 },
                        label = { Text("Tài khoản") })
                }
                if (tab == 1) {
                    Text("BẢNG XẾP HẠNG TRÊN THIẾT BỊ", color = Lime)
                    Text("1. $username  •  $totalReps lần",
                        modifier = Modifier.padding(top = 10.dp))
                    Text("Bản hiện tại chưa đồng bộ người chơi khác.",
                        color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                } else if (tab == 2) {
                    Text("Tên: $username")
                    Text("Tổng số lần: $totalReps")
                    Text("Tổng plank tốt nhất: ${totalPlankSeconds}s")
                    TextButton(onClick = {
                        prefs.edit().clear().apply()
                        username = ""
                        nameInput = ""
                        totalReps = 0
                        totalPlankSeconds = 0
                    }) { Text("Đăng xuất / đổi tên") }
                } else {
                    Spacer(Modifier.weight(1f))
                    Text("Camera xử lý trực tiếp trên điện thoại. Không tải video lên máy chủ.",
                        color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
