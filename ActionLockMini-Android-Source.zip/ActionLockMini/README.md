# ActionLock Mini — Android prototype

## Included in this first prototype
- Local username profile (no email/password yet)
- CameraX live preview
- ML Kit Pose Detection in STREAM_MODE
- Basic squat repetition state machine (knee angle thresholds)
- Local total repetition counter and simple local leaderboard placeholder
- Dark interface

## Build
1. Install Android Studio and Android SDK Platform 36.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone, enable USB debugging, then Run.
5. Grant camera permission when prompted.

## Important limitations in v0.1
- This is a prototype, not a medical/fitness coach. Camera angle, clothing, lighting and body position affect recognition. Stop if uncomfortable; use a comfortable range of motion.
- The rep counter is a basic heuristic and needs testing/calibration on real devices.
- Account data is local only. Online accounts and a real multi-user leaderboard need a backend such as Firebase.
- Actual app blocking is not implemented yet. Android does not provide ordinary apps with unrestricted power to block other apps. A future version can use user-enabled Android usage/accessibility features with clear consent and a safe emergency exit.
- The app does not record or upload camera video. Pose processing happens on-device.
