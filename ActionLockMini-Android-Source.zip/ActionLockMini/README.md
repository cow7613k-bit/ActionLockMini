# ActionLock Mini — Android prototype v0.2

## Added in v0.2
- Workout selector: squat, push-up, plank.
- In-session progress bar and target.
- Squat requires a deep knee bend (below about 95 degrees), a short stable bottom phase, then near-full extension (above about 165 degrees) held briefly.
- Push-up uses elbow angle, requiring a low phase and near-full extension.
- Plank timer advances only while shoulder-hip-ankle alignment is detected.
- Local total rep and best plank duration storage.

## Build
1. Open this project in Android Studio or use the included GitHub Actions workflow approach.
2. Android SDK Platform 36 and Java 17 are required.
3. Build with `gradle assembleDebug` from the project directory.

## Important limitations
- Camera pose recognition is heuristic. Camera angle, lighting, clothing, device position and individual movement affect accuracy. Thresholds need testing and calibration on the actual phone.
- For squat, use a side view with feet, knees and hips visible. For push-ups and plank, use a side/diagonal view.
- Plank is measured in seconds, not repetitions.
- This is a fitness habit prototype, not a medical device or form coach. Use comfortable movement ranges and stop if there is pain, dizziness or unusual discomfort.
- No real app blocking, online accounts, or multi-user leaderboard yet.
- Camera frames are processed on-device; video is not saved or uploaded.
